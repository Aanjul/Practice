

const data = require( "./car");
console.log('Car Name:');


const word= 'name';

console.log(data);
console.log('    	Car Name:' + data[0].carname );
//console.log('       Date:' + );

{/* <script type="text/javascript" src="car.json">
    
</script> */}

// const cardata = require ("./car.json");



